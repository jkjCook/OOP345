//Justin Cook
#include "process.h"
using namespace std;

void process(char *x) {
   w1::CString A(x);
   cout << A << endl;
}