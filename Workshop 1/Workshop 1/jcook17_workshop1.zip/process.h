#ifndef PROCESS_H
#define PROCESS_H
#include <iostream>
#include "CString.h"

void process(char *x);

#endif